---
title: Modern Engineering Textbook
date: 2016-04-20 00:00:00 +0000
categories: []
description: 'Computer-Based Training for Cogntive Behavioural Therapy: An Addictions
  Program for Canada'
banner_image: "/uploads/2018/02/17/bridge3.jpg"
sub_heading: A post-modern taking on Engineering in the Digital World
tags:
- engineering
- research
slug: ''
---

## Overview

Resident Professors Murphy Tiernan and Kelly Brewer have collaborated over the last 3 years with leading professionals in the continental US to develop a modern curriculum for Engineering students.

## Editions

* Edition One - 2016

* Edition Two - 2017
