---
title: Example Draft
layout: post
date: 2018-01-19 00:00:00 +0000
sub_heading: ''
tags: []
related_posts: []

---
## What are draft posts?

This is an example of a draft post. Draft posts aren't included when publishing your site.

This is great for authoring work in progress content, or hiding content that shouldn't be available at the current time.

![](/uploads/2018/02/17/building.jpg)