---
title: Grady Nerio
date: 2017-11-14 10:00:44 +0000
role:
- partner
- board
thumbnail: "/uploads/2017/11/14/filipe-almeida-192048 (1).jpg"
sub_heading: Head of Board
email: grady@belkirkcollege.com
linkedin: ''
layout: 'person'
---

Grady Nerio joined the Belkirk Board in 2015.

Grady received his Ph.D in Mechanical Engineering from Stanford in 1978, and has worked with prestigious companies such as Boeing and Lockheed Martin.

Nulla vitae elit libero, a pharetra augue. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Nullam quis risus eget urna mollis ornare vel eu leo. Cras mattis consectetur purus sit amet fermentum. Aenean lacinia bibendum nulla sed consectetur.
