---
title: Martin Marino
date: 2017-11-14 11:08:34 +0000
role:
- advisor
- board
sub_heading: Advisor
thumbnail: "/uploads/2017/11/14/joseph-gonzalez-399972.jpg"
email: martin@belkirkcollege.com
linkedin: ''
layout: 'person'
---

Martin Marino joined Belkirk in 2016 as an advisor and member of the Board.

Martin has his master's degree in Finance and has started three successful engineering-related ventures since 2012, and currently advises the boards of United Technologies and Bechtel.

Nulla vitae elit libero, a pharetra augue. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Nullam quis risus eget urna mollis ornare vel eu leo. Cras mattis consectetur purus sit amet fermentum. Aenean lacinia bibendum nulla sed consectetur.
