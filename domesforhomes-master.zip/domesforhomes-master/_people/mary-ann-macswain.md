---
title: Mary-Ann MacSwain
date: 2016-11-08 00:00:00 +0000
description: ''
email: maryanne@belkirkcollege.ca
linkedin: ''
role:
- staff
- advisor
slug: ''
sub_heading: Research Chair
tags:
- radssfdfdsfds fdfasdfd saffdssfd
thumbnail: "/uploads/2017/11/14/jeffrey-wegrzyn-183858.jpg"
layout: 'person'
---

Mary-Ann MacSwain joined Belkirk in 2016 as a Data Analyst.

Mary-Ann received her B.A. (Honours) in Psychology from Dartmouth, where she is currently completing her MSc in Epidemiology.

Nulla vitae elit libero, a pharetra augue. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Nullam quis risus eget urna mollis ornare vel eu leo. Cras mattis consectetur purus sit amet fermentum. Aenean lacinia bibendum nulla sed consectetur.
