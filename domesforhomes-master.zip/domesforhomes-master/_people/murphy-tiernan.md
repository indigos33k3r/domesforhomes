---
title: Murphy Tiernan
date: 2017-11-14 10:47:11 +0000
role:
- advisor
- staff
thumbnail: "/uploads/2017/11/14/andrew-robles-300868.jpg"
sub_heading: Professor
email: murphy@belkirkcollege.com
linkedin: ''
layout: 'person'
---

Doctor Murphy Tiernan joined Belkirk in 2015 as a Professor.

He received his Ph.D in Civil Engineering from Stanford in 2003, and also holds a master's degree in Mechanical Engineering.

Nulla vitae elit libero, a pharetra augue. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Nullam quis risus eget urna mollis ornare vel eu leo. Cras mattis consectetur purus sit amet fermentum. Aenean lacinia bibendum nulla sed consectetur.
