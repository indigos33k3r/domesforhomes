---
title: Kellie Brewer
date: 2017-11-14 10:59:07 +0000
role:
- advisor
- staff
sub_heading: Professor
thumbnail: "/uploads/2017/11/14/alejandra-higareda-295605.jpg"
email: ''
linkedin: ''
layout: 'person'
---

Kellie Brewer joined Belkirk in 2014 as a Professor of Engineering.

Kellie received her Ph.D in Biomedical Engineering from Duke University in 2007. Since graduating, Kelly has worked with Randstad Engineering as Head of Research and Development in San Jose, California.

Nulla vitae elit libero, a pharetra augue. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Nullam quis risus eget urna mollis ornare vel eu leo. Cras mattis consectetur purus sit amet fermentum. Aenean lacinia bibendum nulla sed consectetur.
