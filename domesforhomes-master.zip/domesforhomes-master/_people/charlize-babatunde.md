---
title: Charlize Babatunde
date: 2017-11-14 10:54:31 +0000
role:
- staff
thumbnail: "/uploads/2017/11/14/william-stitt-162611.jpg"
sub_heading: Administration
email: ''
linkedin: ''
layout: 'person'
---

Charlize Babatunde joined Belkirk in 2015 as Head of Administration.

Charlize graduated with a master's degree in Industrial and Labor Relations and master's degree in Business Administration from Cornell in 2008, and worked with various non-profits before joining Belkirk..

Nulla vitae elit libero, a pharetra augue. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Nullam quis risus eget urna mollis ornare vel eu leo. Cras mattis consectetur purus sit amet fermentum. Aenean lacinia bibendum nulla sed consectetur.
